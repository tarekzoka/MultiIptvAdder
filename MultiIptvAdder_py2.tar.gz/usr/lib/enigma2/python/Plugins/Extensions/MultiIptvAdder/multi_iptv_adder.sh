#!/bin/bash
dir="/usr/lib/enigma2/python/Plugins/Extensions/MultiIptvAdder/iptv.txt"
if [ ! -s "$dir" ]; then
  echo "> url= None"
  echo "> port= None"
  echo "> username= None"
  echo "> password= None"
  sleep 2
  echo "Write and save a new iptv user, then try again..."
  sleep 1
  exit 1
fi

read -r url port username password < "$dir"
echo "> url= $url"
echo "> port= $port"
echo "> username= $username"
echo "> password= $password"

declare -A files=(
  ["bouquetmakerxtream"]="/etc/enigma2/bouquetmakerxtream/playlists.txt"
  ["jediplaylists"]="/etc/enigma2/jediplaylists/playlists.txt"
  ["xklass"]="/etc/enigma2/xklass/playlists.txt"
  ["xstreamity"]="/etc/enigma2/xstreamity/playlists.txt"
  ["e2iplayer"]="/etc/enigma2/e2iplayer/playlists.txt"
  ["xcplugin"]="/etc/enigma2/xc/xclink.txt"
)

if [ -f "/etc/enigma2/iptosat.conf" ]; then
  > /etc/enigma2/iptosat.conf
  cat <<EOF >> /etc/enigma2/iptosat.conf
[IPtoSat]
Host=$url
User=$username
Pass=$password
EOF
  echo "> your iptv data installed in iptosat config file successfully"
  sleep 3
else
  echo "> iptosat config file not found"
  sleep 3
fi

for playlist in "${!files[@]}"; do
  if [ ! -f "${files[$playlist]}" ]; then
    echo "> $playlist playlists file not found"
    sleep 3
  else
    if ! grep -q "$username" "${files[$playlist]}"; then
      cat <<EOF >> "${files[$playlist]}"
$url:$port/get.php?username=$username&password=$password&type=m3u
EOF
      echo "> your iptv data installed in $playlist playlists file successfully"
      sleep 3
    else
      echo "> your iptv data already installed in $playlist playlists file"
      sleep 3
    fi
  fi
done



