from setuptools import setup, find_packages

   setup(
       name="MultiIptvAdder",
       version="1.0",
       packages=find_packages(),
       include_package_data=True,
       install_requires=[],
       entry_points={},
       data_files=[
           ("/usr/lib/enigma2/python/Plugins/Extensions/MultiIptvAdder", ["icon.png", "multi_iptv_adder.sh"]),
       ]
   )
